function getGenResultsJSON()
{
var general_resultsJSON = 
{"Action":"INACTIVE","CVE":"","Confidence":"CONFIDENCE_HIGH","Severity":"Critical","Verdict":"Malicious","malicious_engines":["advisory","bd","embedded files","metascan","ml decider genie"]}
;
 return general_resultsJSON;
}