function getClassificationJSON()
{
var classificationJSON = 
["Trojan","behavior"]
;
 return classificationJSON;
}