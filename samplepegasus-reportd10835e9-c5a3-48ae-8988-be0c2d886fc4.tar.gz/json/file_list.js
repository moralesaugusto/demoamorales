function getFileListJSON()
{
var file_listJSON = 
[{"context":"Embedded","file_name":"samplepegasus.pdf/Embedded_{50B88883-39DC-564A-B2F6-259D22F7BBFD}_sample5.apk","file_size":263823,"file_type":"jar","md5":"7c3ad8fec33465fed6563bbfabb5b13d","path":"file_list/f1/ThreatEmulationReport.html","uid":"{1C1218F0-A8CF-574E-B0F4-E752E8B9819E}-{0190D0AF-918C-D148-B4EC-F17FE3638FB8}","verdict":"Malicious"}]
;
 return file_listJSON;
}