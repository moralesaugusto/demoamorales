function getAttackComponentsJSON()
{
var attack_componentsJSON = 
{"children":[{"children":[],"file_type":"jar","filename":"Embedded_{50B88883-39DC-564A-B2F6-259D22F7BBFD}_sample5.apk","id":1,"md5":"7c3ad8fec33465fed6563bbfabb5b13d","relationship":"Embedded","sha1":"e5920f3723e62e1850157f09baf556006bf80f74","sha256":"ade8bef0ac29fa363fc9afd958af0074478aef650adeb0318517b48bd996d5d5","type":"file","verdict":"Malicious"}],"file_type":"pdf","filename":"samplepegasus.pdf","id":0,"md5":"dec1929900b3984482c62905ed2d6588","relationship":"original","sha1":"0e77ece6d4cb77ebdc1672db5abc7c102ac9948d","sha256":"593a2aeb1580755bb6426e9ff351a53c62045e55de739f90d722b757d6c71534","type":"file","verdict":"Malicious"}
;
 return attack_componentsJSON;
}