function getTechDetailsJSON()
{
var tech_detailsJSON = 
{"cloud_dns_name":"te-us.iaas.checkpoint.com","file_name":"593a2aeb1580755bb6426e9ff351a53c62045e55de739f90d722b757d6c71534","file_path":"samplepegasus.pdf","file_size":264938,"file_type":"pdf","gw_id":"ce-10-7-130-240-c5-2xlarge-4568529-prod-p","images":[{"name":"Win7 64b,Office 2010,Adobe 11 (Web)","uid":"3ff3ddae-e7fd-4969-818c-d5f1a2be336dWEB","verdict":"Malicious"},{"name":"WinXP,Office 2003/7,Adobe 9 (Web)","uid":"e50e99f3-5963-4573-af9e-e3f4750b55e2WEB","verdict":"Malicious"}],"md5":"dec1929900b3984482c62905ed2d6588","protocol":"http","sha1":"0e77ece6d4cb77ebdc1672db5abc7c102ac9948d","sha256":"593a2aeb1580755bb6426e9ff351a53c62045e55de739f90d722b757d6c71534"}
;
 return tech_detailsJSON;
}