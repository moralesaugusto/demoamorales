function getPcaps()
{
var pcaps = 
[{"image_uid":"3ff3ddae-e7fd-4969-818c-d5f1a2be336dWEB","url":"pcaps/3ff3ddae.pcap"},{"image_uid":"e50e99f3-5963-4573-af9e-e3f4750b55e2WEB","url":"pcaps/e50e99f3.pcap"}]
;
 return pcaps;
}