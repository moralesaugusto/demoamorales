function getDetailedBehavioralReports()
{
var detailedBehavioralReports = 
[]
;
 return detailedBehavioralReports;
}