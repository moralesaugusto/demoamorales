function getAttackVectorJSON()
{
var attack_vectorJSON = 
{"protocol":"irrelevant"}
;
 return attack_vectorJSON;
}