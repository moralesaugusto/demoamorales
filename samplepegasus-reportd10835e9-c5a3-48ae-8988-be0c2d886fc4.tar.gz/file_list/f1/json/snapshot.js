function getSnapshotJSON()
{
var SnapshotJSON = 
[]
;
 return SnapshotJSON;
}