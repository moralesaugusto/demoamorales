function getFileListJSON()
{
var file_listJSON = 
[];
 return file_listJSON;
}