function getSuspActvJSON()
{
var spsactJSON = 
{"images":[{"behaviors":[{"category":"General","count":2,"description":"Static Analysis","values":[{"type":"Suspicious activity","value":"Malware detected ( Trojan.Generic.39592600;Trojan.Generic.39625314 )"},{"type":"Suspicious activity","value":"Malware signature matched ( Trojan.Win32.Pegasus.TC.01e9JXOd )"}]}],"image":"Win7 64b,Office 2010,Adobe 11"},{"behaviors":[{"category":"General","count":2,"description":"Static Analysis","values":[{"type":"Suspicious activity","value":"Malware detected ( Trojan.Generic.39592600;Trojan.Generic.39625314 )"},{"type":"Suspicious activity","value":"Malware signature matched ( Trojan.Win32.Pegasus.TC.01e9JXOd )"}]}],"image":"WinXP,Office 2003/7,Adobe 9"}]}
;
 return spsactJSON;
}