function getEmulationEventsJSON_3ff3ddae()
{
var emulationEventsJSON_3ff3ddae = 
[]
;
 return emulationEventsJSON_3ff3ddae;
}