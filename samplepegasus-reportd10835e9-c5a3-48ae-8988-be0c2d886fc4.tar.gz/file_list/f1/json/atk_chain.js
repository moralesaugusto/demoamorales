function getAttackChainJSON()
{
var attack_chainJSON = 
{}
;
 return attack_chainJSON;
}