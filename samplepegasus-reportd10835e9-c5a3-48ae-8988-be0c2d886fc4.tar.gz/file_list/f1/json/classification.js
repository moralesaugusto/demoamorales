function getClassificationJSON()
{
var classificationJSON = 
["Trojan"]
;
 return classificationJSON;
}