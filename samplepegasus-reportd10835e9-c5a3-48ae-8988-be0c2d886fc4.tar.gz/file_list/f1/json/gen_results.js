function getGenResultsJSON()
{
var general_resultsJSON = 
{"Action":"INACTIVE","CVE":"","Confidence":"CONFIDENCE_HIGH","Severity":"Critical","Verdict":"Malicious","malicious_engines":["bd","threat_cloud_features","virus total"]}
;
 return general_resultsJSON;
}