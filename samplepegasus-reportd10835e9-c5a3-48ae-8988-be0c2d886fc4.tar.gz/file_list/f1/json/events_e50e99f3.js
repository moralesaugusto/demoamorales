function getEmulationEventsJSON_e50e99f3()
{
var emulationEventsJSON_e50e99f3 = 
[]
;
 return emulationEventsJSON_e50e99f3;
}