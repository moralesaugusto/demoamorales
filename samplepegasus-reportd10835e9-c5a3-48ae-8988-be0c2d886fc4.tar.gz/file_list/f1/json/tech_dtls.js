function getTechDetailsJSON()
{
var tech_detailsJSON = 
{"cloud_dns_name":"te-us.iaas.checkpoint.com","context":"Embedded","file_name":"ade8bef0ac29fa363fc9afd958af0074478aef650adeb0318517b48bd996d5d5","file_path":"samplepegasus.pdf/Embedded_{50B88883-39DC-564A-B2F6-259D22F7BBFD}_sample5.apk","file_size":263823,"file_type":"jar","gw_id":"ce-10-7-130-240-c5-2xlarge-4568529-prod-p","images":[{"name":"Win7 64b,Office 2010,Adobe 11","uid":"3ff3ddae-e7fd-4969-818c-d5f1a2be336d","verdict":"Malicious"},{"name":"WinXP,Office 2003/7,Adobe 9","uid":"e50e99f3-5963-4573-af9e-e3f4750b55e2","verdict":"Malicious"}],"md5":"7c3ad8fec33465fed6563bbfabb5b13d","protocol":"http","sha1":"e5920f3723e62e1850157f09baf556006bf80f74","sha256":"ade8bef0ac29fa363fc9afd958af0074478aef650adeb0318517b48bd996d5d5"}
;
 return tech_detailsJSON;
}