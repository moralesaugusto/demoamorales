/**
 * Class for creating snapshot image objects.
 *
 * @param {string} containerSelector Selector for the container where the image should be added.
 * @param {object} jsonData JSON data that contains the image path and name.
 */
function SnapshotImage(containerSelector, jsonData) {
  this.container = containerSelector;
  this.imageUrl = jsonData.url;
  this.image_name = jsonData.url.split('/').pop();

  const thumbnail = $('<div class="snap-images-thumbnail"></div>').appendTo($(this.container));

  const imageEl = $('<div class="snap-image-screenshot"> \
    <img src="' + this.imageUrl + '"> \
  </div>').appendTo(thumbnail);

  // Image click opens modal
  imageEl.on('click', function() {
    $('#snap-modal-img').attr('src', jsonData.url);
    $('#snap-modal').fadeIn();
  });

  // Close modal
  $('.snap-modal-close').on('click', function() {
    $('#snap-modal').fadeOut();
  });
}

$(document).ready(function() {
  const data = getSnapshotImageJSON();
  if (data.length > 0) {
    new SnapshotImage('#snap-image', data[0]);
  } else {
    $('#snap-image').parents('.panel').remove();
  }
});
