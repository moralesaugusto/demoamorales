// Used as a class to load each of the sections in the report.
function LoadJSON() {

	/* The events for each image are saved in this object, in order to save data
	   and share it with other sections (using their respective API) */
	this.eventsPerImage = {};

	this.fileMD5 = '';

	// An object to link between various file types (not extensions) to their image.
	var fileTypeImages = {
		Adobe: "images/file_types/adobe.svg",
		Archive: "images/file_types/archive.svg",
		Code: "images/file_types/code.svg",
		Document: "images/file_types/document.svg",
		Excel: "images/file_types/excel.svg",
		Executable: "images/file_types/executable.svg",
		Image: "images/file_types/image.svg",
		Jar: "images/file_types/jar.svg",
		Javascript: "images/file_types/javascript.svg",
		None: "images/file_types/none.svg",
		Powerpoint: "images/file_types/powerpoint.svg",
		Python: "images/file_types/python.svg",
		Spreadsheet: "images/file_types/spreadsheet.svg",
		Text: "images/file_types/text.svg",
		Unknown: "images/file_types/unknown.svg",
		Video: "images/file_types/video.svg",
		Windows: "images/file_types/windows.svg",
		Word: "images/file_types/word.svg",
	};

	// An object to link between various file extensions to their file type.
	var fileTypes = {
		// Adobe
		pdf:	fileTypeImages["Adobe"],
		swf:	fileTypeImages["Adobe"],

		// Archive
		zip:		fileTypeImages["Archive"],
		"7z":		fileTypeImages["Archive"],
		rar:		fileTypeImages["Archive"],
		cab:		fileTypeImages["Archive"],
		tar:		fileTypeImages["Archive"],
		"tar.gz":	fileTypeImages["Archive"],
		tgz:		fileTypeImages["Archive"],
		iso:		fileTypeImages["Archive"],
		gz:			fileTypeImages["Archive"],
		gzip:		fileTypeImages["Archive"],
		bz2:		fileTypeImages["Archive"],
		tbz2:		fileTypeImages["Archive"],
		tb2:		fileTypeImages["Archive"],
		tbz:		fileTypeImages["Archive"],
		xz:		fileTypeImages["Archive"],
		txz:		fileTypeImages["Archive"],

		// Code
		htm:	fileTypeImages["Code"],
		html:	fileTypeImages["Code"],
		vbs:	fileTypeImages["Code"],
		vba:	fileTypeImages["Code"],
		vbe:	fileTypeImages["Code"],

		// Document
		hwp:	fileTypeImages["Document"],

		// Excel
		xls:	fileTypeImages["Excel"],
		xlsx:	fileTypeImages["Excel"],
		xlt:	fileTypeImages["Excel"],
		xlm:	fileTypeImages["Excel"],
		xltx:	fileTypeImages["Excel"],
		xlsm:	fileTypeImages["Excel"],
		xltm:	fileTypeImages["Excel"],
		xlsb:	fileTypeImages["Excel"],
		xla:	fileTypeImages["Excel"],
		xlam:	fileTypeImages["Excel"],
		xll:	fileTypeImages["Excel"],
		xlw:	fileTypeImages["Excel"],

		// Executable
		exe:	fileTypeImages["Executable"],
		com:	fileTypeImages["Executable"],

		// Image
		bmp:	fileTypeImages["Image"],

		// Jar
		jar:	fileTypeImages["Jar"],

		// Javascript
		js:		fileTypeImages["Javascript"],
		jse:	fileTypeImages["Javascript"],

		// None
		"":		fileTypeImages["None"],

		// Powerpoint
		ppt:	fileTypeImages["Powerpoint"],
		pptx:	fileTypeImages["Powerpoint"],
		pps:	fileTypeImages["Powerpoint"],
		pptm:	fileTypeImages["Powerpoint"],
		potx:	fileTypeImages["Powerpoint"],
		potm:	fileTypeImages["Powerpoint"],
		ppam:	fileTypeImages["Powerpoint"],
		ppsx:	fileTypeImages["Powerpoint"],
		ppsm:	fileTypeImages["Powerpoint"],
		sldx:	fileTypeImages["Powerpoint"],
		sldm:	fileTypeImages["Powerpoint"],

		// Python
		py:		fileTypeImages["Python"],
		py3:	fileTypeImages["Python"],
		pyc:	fileTypeImages["Python"],
		pyo:	fileTypeImages["Python"],
		pyw:	fileTypeImages["Python"],
		pyx:	fileTypeImages["Python"],
		pyd:	fileTypeImages["Python"],
		pxd:	fileTypeImages["Python"],
		pxi:	fileTypeImages["Python"],
		pyi:	fileTypeImages["Python"],
		pyz:	fileTypeImages["Python"],
		pywz:	fileTypeImages["Python"],

		// Spreadsheet
		csv: fileTypeImages["Spreadsheet"],

		// Text
		rtf: fileTypeImages["Text"],
		txt: fileTypeImages["Text"],

		// Unknown
		unknown: fileTypeImages["Unknown"],

		// Video
		ra: fileTypeImages["Video"],
		ram: fileTypeImages["Video"],
		mov: fileTypeImages["Video"],
		qt: fileTypeImages["Video"],
		rm: fileTypeImages["Video"],

		// Windows
		scr: fileTypeImages["Windows"],
		pif: fileTypeImages["Windows"],
		wsf: fileTypeImages["Windows"],
		xap: fileTypeImages["Windows"],
		wsh: fileTypeImages["Windows"],
		ps1: fileTypeImages["Windows"],
		cpl: fileTypeImages["Windows"],

		// Word
		doc: fileTypeImages["Word"],
		docx: fileTypeImages["Word"],
		dot: fileTypeImages["Word"],
		docm: fileTypeImages["Word"],
		dotx: fileTypeImages["Word"],
		dotm: fileTypeImages["Word"],
	};

	// Just following the DRY priniple.
	var verdicts = {
		MALICIOUS: {
			img: "images/malicious.svg",
			text: "Malicious"
		},
		BENIGN: {
			img: "images/benign.svg",
			text: "Benign"
		},
		ERROR: {
			img: "images/error.svg",
			text: "Error"
		}
	};

	/**
	 * Returns a human-readable file size.
	 *
	 * @param  {number}	a File size in bytes.
	 * @param  {number}	b Number of digits after floating point.
	 * @return {string}	  Human readable format of the file size.
	 */
	function formatBytes(a,b){if(0==a)return"0 Bytes";var c=1024,d=b||2,e=["Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"],f=Math.floor(Math.log(a)/Math.log(c));return parseFloat((a/Math.pow(c,f)).toFixed(d))+" "+e[f]}

	/**
	 * Appends a <script> tag to the HTML and calls a function when it's done loading.
	 *
	 * @param {function} func The function to call.
	 * @param {string}	 src  Path to the script file.
	 */
	var addScript = function(func, src) {
		var script = document.createElement('script');
		script.onload = func;
		script.src = src;
		document.body.appendChild(script);
	}

	function build_xdr_intelligence_link(cloud_dns_name, data, sourceField="") {
		// data might be 'md5' or 'url'.
		// Redirection to 'portal.checkpoint.com/dashboard/xdr-xpr/xdrxpr' using load balancing - THREATEMUL-12339
		const path = "xdr";
		let query_data = `[{"indicator":"${data}","sourceIndicator":"Threat Report","sourceField":"${sourceField}"}]`;
		query_data = `indicators=${btoa(encodeURIComponent(query_data))}#/investigate`;
		return `https://${cloud_dns_name}/${path}?${query_data}`;
	}

	// Stored globally in the class to avoid reading the same JSON twice (becuase it's data is being used in more than one section, as opposed to other JSON files)
	this.tech_details_json = getTechDetailsJSON();

	// All the images the file was emulated on
	this.images = this.tech_details_json.images;

	// Fix image names (add space after comma)
	for (var image in this.images)
		this.images[image].name = this.images[image].name.replace(/,/g, ', ');

	/////////////////////
	// General Results //  (upper section)
	/////////////////////
	this.general_results = () => {
		var actions = {
			INACTIVE: {
				img: "",
				text: "Inactive"
			},
			DETECT: {
				img: "images/actions/detect.svg",
				text: "Detect"
			},
			PREVENT: {
				img: "images/actions/prevent.svg",
				text: "Prevent"
			},
			ASK: {
				img: "images/actions/ask.svg",
				text: "Ask"
			},
			ACCEPT: {
				img: "images/actions/accept.svg",
				text: "Allow"
			}
		};

		var confidenceLevels = {
			CONFIDENCE_HIGH: {
				img: "images/confidence/high.svg",
				text: "High"
			},
			CONFIDENCE_MEDIUM: {
				img: "images/confidence/medium.svg",
				text: "Medium"
			},
			CONFIDENCE_LOW: {
				img: "images/confidence/low.svg",
				text: "Low"
			},
			CONFIDENCE_NONE: {
				img: "images/confidence/none.svg",
				text: "None"
			}
		};

		var riskLevels = {
			INFO: {
				img: "images/risk/info.svg",
				text: "Info"
			},
			LOW: {
				img: "images/risk/low.svg",
				text: "Low"
			},
			MEDIUM: {
				img: "images/risk/medium.svg",
				text: "Medium"
			},
			HIGH: {
				img: "images/risk/high.svg",
				text: "High"
			},
			CRITICAL: {
				img: "images/risk/critical.svg",
				text: "Critical"
			}
		};

		var classifications = {
			ADWARE: {
				img: "images/attacks/adware.svg",
				text: "Adware"
			},
			BACKDOOR: {
				img: "images/attacks/backdoor.svg",
				text: "Backdoor"
			},
			BANKER: {
				img: "images/attacks/banker.svg",
				text: "Banker"
			},
			BOT: {
				img: "images/attacks/bot.svg",
				text: "Bot"
			},
			DOWNLOADER: {
				img: "images/attacks/downloader.svg",
				text: "Downloader"
			},
			INFOSTEALER: {
				img: "images/attacks/infostealer.svg",
				text: "Infostealer"
			},
			PHISHING: {
				img: "images/attacks/phishing.svg",
				text: "Phishing"
			},
			RANSOMWARE: {
				img: "images/attacks/ransomware.svg",
				text: "Ransomware"
			},
			ROOTKIT: {
				img: "images/attacks/rootkit.svg",
				text: "Rootkit"
			},
			TROJAN: {
				img: "images/attacks/trojan.svg",
				text: "Trojan"
			},
			VIRUS: {
				img: "images/attacks/virus.svg",
				text: "Virus"
			},
			WORM: {
				img: "images/attacks/worm.svg",
				text: "Worm"
			},
			"PROMPT INJECTION": {
				img: "images/attacks/prompt_injection.svg",
				text: "Prompt Injection"
			}
		};

		// Get "General Results" data
		var data = getGenResultsJSON();

		// Verdict
		var verdict = verdicts[data.Verdict.toUpperCase()];
		$('#verdict').text(verdict.text);
		$('#verdict_img').attr('src', verdict.img);

		// Action
		var action = actions[data.Action.toUpperCase()];
		$('#action').text(action.text);
		$('#action_img').attr('src', action.img);

		// Secure / Risk / Severity
		var risk = riskLevels[data.Severity.toUpperCase()];
		$('#risk').text(risk.text);
		$('#risk_img').attr('src', risk.img);

		// Confidence
		var confidence = confidenceLevels[data.Confidence.toUpperCase()];
		$('#confidence').text(confidence.text);
		$('#confidence_img').attr('src', confidence.img);

        // Cve
		var cve = data.CVE;
        if (cve)
        {
            $('#cve-link').text(cve.toUpperCase());
            $('#cve-link').attr('href', 'https://cve.mitre.org/cgi-bin/cvename.cgi?name=' + cve.toUpperCase());
        }
        else {
            $('#cve-link').remove();
        }

		var invalid_commonly_stolen_certificate = data.invalid_commonly_stolen_certificate;
		if (invalid_commonly_stolen_certificate)
		{
			$('#invalid_commonly_stolen_certificate').text(invalid_commonly_stolen_certificate);
		}
		else {
			$('#invalid_commonly_stolen_certificate').remove();
		}

		/**
		 * Classification
		 *
		 * The classification JSON file is independant but really no reason for another function since it's in the same section in the report.
		 * Limiting the amount of classifications to 4.
		 * First, classifications that are not familiar (don't have a matching icon) are filtered out.
		 */
		var filteredClassifications = getClassificationJSON().filter(c => c.toUpperCase() in classifications);
		var _classifications = filteredClassifications.slice(0, 4).map(c => classifications[c.toUpperCase()]);

		if (_classifications.length === 0) {
			$('#classification_item').hide();
		}

		// Dividing the classification text into 2 lines if it's too long
		if(_classifications.length > 2) {
			var classifications_txt_array = _classifications.map(c => c.text);
			$('#classification').append(classifications_txt_array.slice(0, classifications_txt_array.length/2).join(", ")
				+ ', <br/>' + classifications_txt_array.slice(classifications_txt_array.length/2).join(", "));
		}
		else {
			$('#classification').append(_classifications.map(c => c.text).join(', '));
		}

		$('#classification_images').append(_classifications.map(c => '<img src="' + c.img + '">').join(''));

		// Make the classification images layout look pretty
		if ($('#classification_images img').length == 3) {
			$('#classification_images img:nth-child(2)').before('<br>');
			$('#classification_images').addClass('small_classification');
		} else if ($('#classification_images img').length == 4) {
			$('#classification_images img:nth-child(3)').before('<br>');
			$('#classification_images').addClass('small_classification');
		}

		var briefImageHeight = parseInt($('.brief-item:first-child img').css('height'));
		var classificationImagesHeight =  parseInt($('#classification_images').css('height'));
		if(classificationImagesHeight > briefImageHeight) {
			var classificationImagesPadding = parseInt($('#classification_images').css('padding-top'));
			var paddingToAdd = classificationImagesHeight - briefImageHeight;
			$('#classification_images').css('padding-top', (classificationImagesPadding + paddingToAdd) + 'px');
		}

		// Convicted By
		var convicted_by = data.convicted_by;
		if (convicted_by) {
			var convicted_by_display_names = {
				'zipper': 'See-Through Password Protected Zip'
			};
			$('#convicted_by').text(convicted_by_display_names[convicted_by] || convicted_by);
			$('#convicted_by_item').show();
		}
	};

	///////////////////////
	// Technical Details //
	///////////////////////
	this.tech_details = () => {
		var data = this.tech_details_json;

		document.title = data.file_name + ' - Threat Details Report'

		// ~~~ Meta Data ~~~
		$('#file_name').text(data.file_name);
		$('#file_size').text(formatBytes(data.file_size));

		var fileType = data.file_type.toLowerCase();
		$('#file_type').text(fileType);
		$('#file_img').attr('src', fileTypes.hasOwnProperty(fileType) ? fileTypes[fileType] : fileTypes["unknown"]);
		$('.download-file').attr('href', 'mal_file/' + data.sha1.toLowerCase() + '.' + fileType + '.tar.gz');

		// ~~~ Hash List ~~~
		if (data.md5) {
			$('#md5').find('.header_hash').text(data.md5.toUpperCase());
			this.fileMD5 =  data.md5;
		}
		else {
			$('#md5').remove();
			this.fileMD5 = '';
		}

		if (data.sha1) $('#sha1').find('.header_hash').text(data.sha1.toUpperCase());
		else $('#sha1').remove();

		if (data.sha256) $('#sha256').find('.header_hash').text(data.sha256.toUpperCase());
		else $('#sha256').remove();

		// XDR Intelligence link
		if (data.md5)
		{
			$('#xdr-intelligence-link-header').attr('href', build_xdr_intelligence_link(data.cloud_dns_name, data.md5, "original"));
			$('#xdr-intelligence-link-img').attr('src', "images/horizon/horizon.svg");
		}
		else {
			$('#xdr-intelligence-link-wrapper').remove();
		}

		// ~~~ Live Counter ~~~
        // Get the gw id and set it as hidden html value
        gw_id.value = data.gw_id;

		// Get the cloud_dns_name and set it as hidden html value
		cloud_dns_name.value = data.cloud_dns_name;

        // Generate this report browsing uuid and set it as hidden html value
        uuid.value = createUUID();

        // Get current time in milliseconds and set it as hidden html value
        startTimeId.value = Date.now();

        // Send to Threat-Cloud the counting service request during report open
        //console.log('call sendLiveCounterRequest() during report_open');
        //sendLiveCounterRequest(true);

        // Set timer to 10 seconds after which, another counting service will be sent to Threat-Cloud.
		//setTimeout(function () { sendLiveCounterRequest(false); }, 10000);

		// Sends Google Analytics indication that a TE report is being opened
		// (for statistics collection)
		sendOpenReportEventToGoogleAnalytics(data.gw_id);

		// ~~~ File List ~~~
		var data = getFileListJSON();
		var fileList = $('#file_list');

		// If no regular file list but convicted by zipper, populate from archive_metadata entries
		var genResults = getGenResultsJSON();
		if (!data.length) {
			if (genResults.convicted_by === 'zipper' && genResults.archive_entries && genResults.archive_entries.length) {
				var hits = genResults.zipper_filenames_hits || [];
				var zipName = this.tech_details_json.file_path || this.tech_details_json.file_name;
				data = genResults.archive_entries.map(function(entry) {
					var name = entry.Filename;
					return {
						file_name: zipName + '/' + name,
						file_type: '',
						verdict: hits.indexOf(name) !== -1 ? 'Malicious' : 'Benign',
						file_size: parseInt(entry.Size, 10) || 0,
						context: 'archive'
					};
				});
			}
		}

		// Append archive extraction errors (e.g. MAX_READ_BYTES, FILE_TOO_BIG) as rows so the user
		// can see why the archive (or specific entries) failed extraction.
		if (genResults.archive_extraction_errors && genResults.archive_extraction_errors.length) {
			var maliciousEngine = genResults.exclusive_engine ||
				((genResults.malicious_engines && genResults.malicious_engines.length) ? genResults.malicious_engines[0] : '');
			var archiveName = this.tech_details_json.file_path || this.tech_details_json.file_name || 'archive';
			var errorRows = genResults.archive_extraction_errors.map(function(err) {
				var context = 'extraction error: ' + (err.error || 'unknown');
				if (maliciousEngine) {
					context += ' | malicious engine: ' + maliciousEngine;
				}
				return {
					file_name: err.name || archiveName,
					file_type: (err.type || '').toLowerCase(),
					verdict: 'Error',
					file_size: 0,
					context: context
				};
			});
			data = data.concat(errorRows);
		}

		// Check whether there's data to show in the File Tree
		if (data.length) {
			var table = fileList.find('table tbody');

			// Sorting the file list so that files with Malicious verdict will appear before
			data.sort((file1, file2) => ((file1.verdict == "Malicious") ? -1 : 1));

			var hasType = data.some(function(f) { return f.file_type && f.file_type !== ''; });
			var hasContext = data.some(function(f) { return f.context && f.context !== ''; });
			if (!hasType) fileList.find('thead tr td:nth-child(2)').hide();
			if (!hasContext) fileList.find('thead tr td:nth-child(5)').hide();

			for (var file in data) {
				var _file = data[file];
				var fileType = _file.file_type;
				var fileTypeImage = fileTypes.hasOwnProperty(fileType) ? fileTypes[fileType] : fileTypes["unknown"];
				var verdict = verdicts[_file.verdict.toUpperCase()];

				var row = $('<tr></tr>');
				var $nameTd = $('<td></td>');
				if (_file.path) {
					$nameTd.append('<img class="no-print" src="images/external_link.svg">');
				}
				$nameTd.append($('<span></span>').text(_file.file_name));
				row.append($nameTd);
				if (hasType) {
					var $typeTd = $('<td></td>');
					if (fileType) {
						$typeTd.append('<img src="' + fileTypeImage + '">');
						$typeTd.append($('<span></span>').text('.' + fileType));
					}
					row.append($typeTd);
				}
				row.append('<td><img src="' + verdict.img + '" alt="' + verdict.text + '"></td>');
				row.append('<td class="no-print">' + formatBytes(_file.file_size) + '</td>');
				if (hasContext) {
					row.append($('<td class="no-print"></td>').text(_file.context));
				}
				row.appendTo(table);

				if (_file.path)
					row.attr('href', _file.path);
			}

			table.on('click', 'tr[href]', function() {
				window.open($(this).attr('href'));
			});
		}
		// If no data then remove the File Tree box
		else {
			// var row = fileList.parent();
			// if (row.children().length == 1)
			// 	row.remove();
			// else
			// 	fileList.remove();
			fileList.parents('.panel').remove();

		}
	};

	///////////////////
	// Attack Vector //
	///////////////////

	// Returns an image object for the status of the URL
	// (URL from where the file was downloaded - relevant only for HTTP)
	function getUrlStatusImageElem(urlStatus) {
		// For Benign status no image is added
		if ((urlStatus == "") || (urlStatus.toUpperCase() == "BENIGN") || (urlStatus.toUpperCase() == "UNKNOWN"))
			return "";

		var statusImages = {
			MALICIOUS: {
				img: "images/malicious_badge.svg",
			},
			SUSPICIOUS: {
				img: "images/suspicious_badge.svg",
			}
		}
		return '<img src="' + statusImages[urlStatus.toUpperCase()].img + '" class="status">';
	};

	this.attack_vec = () => {
		var data = getAttackVectorJSON();

		if(data.protocol == "smtp") {
			var $fromBlock = $('<div class="stacked"></div>');
			$fromBlock.append('<img src="images/user.svg">');
			$fromBlock.append('<span class="atk_vec_title">From:</span>');
			$fromBlock.append($('<span></span>').text(data.from));

			var $subjectBlock = $('<div class="stacked"></div>');
			$subjectBlock.append('<img src="images/email.svg">');
			$subjectBlock.append('<span class="atk_vec_title">Subject:</span>');
			$subjectBlock.append($('<span></span>').text(data.subject));
			$subjectBlock.append('<span class="atk_vec_title">File Name:</span>');
			$subjectBlock.append($('<span></span>').text(data.file_name));

			var $toBlock = $('<div class="stacked"></div>');
			$toBlock.append('<img src="images/user.svg">');
			$toBlock.append('<span class="atk_vec_title">To:</span>');
			$toBlock.append($('<span></span>').text(data.to));

			$('#atk_vec_inner').append($fromBlock)
				.append('<img src="images/right_arrow.svg">')
				.append($subjectBlock)
				.append('<img src="images/right_arrow.svg">')
				.append($toBlock);

			$('#atk_vec_inner').css("align-items", "center");
		}
		else if(data.protocol == "http") {
			var $urlBlock = $('<div class="stacked"><div class="image_with_status"><img src="images/globe.svg">'
				+ getUrlStatusImageElem(data.url_risk) + '</div></div>');
			$urlBlock.append($('<span></span>').text(data.url));
			$urlBlock.append($('<span></span>').text(data.dst_ip));

			var $fileBlock = $('<div class="stacked"><div class="image_with_status"><img src="'
				+ $('#file_img').attr("src") + '"><img src="images/malicious_badge.svg" class="status"></div></div>');
			$fileBlock.append($('<span></span>').text(data.file_name));

			var $srcBlock = $('<div class="stacked"></div>');
			$srcBlock.append('<img src="images/user.svg">');
			$srcBlock.append($('<span></span>').text(data.src_ip));

			$('#atk_vec_inner').append($urlBlock)
				.append('<img src="images/right_arrow.svg">')
				.append($fileBlock)
				.append('<img src="images/right_arrow.svg">')
				.append($srcBlock);
		}
		else {
			$('#atk_vec').remove();
		}

		$('#timestamp').text(data.time_stamp_local);
	}

	function itemToIcon(d) {
		switch (d.type) {
			case 'file':
				return "images/graph/file.svg"
			case 'url':
				return 'images/graph/url.svg';
			case 'macro':
			case 'xlm_macro':
				return 'images/graph/macro.svg';
			default:
				return 'images/file_types/unknown.svg';
		}
	}

	function dataNodeToLabel(dataNode) {
		switch (dataNode.type) {
			case 'file':
				return dataNode.relationship === 'original' ? 'File' : dataNode.file_type.toUpperCase();
			case 'url':
				return dataNode.relationship + ' URL';
			case 'macro':
				return 'VBA Macro';
			case 'xlm_macro':
				return 'XLM Macro';
		}
	}

	function capitalizeFirstLetter(str) {
		return str.charAt(0).toUpperCase() + str.slice(1);
	}

	function adjustProperties(property) {
		const properties = {
			'file_type': "File Type",
			'filename': "File Name",
			'sha1': "SHA1",
			'sha256': "SHA256",
			'md5': "MD5",
			'url': "URL",
			'risk': "Risk Score"
		};

		return properties[property] || capitalizeFirstLetter(property);
	}

	this.components = () => {

		const attackComponentsJSON = getAttackComponentsJSON();
		const suspiciousActivityJson = getSuspActvJSON();

		if (!('children' in attackComponentsJSON) || attackComponentsJSON['children'].length < 1) {
			throw 'Not enough data to display the components graph';
		}

		const container = document.getElementById("components_inner");
		const nodesData = [attackComponentsJSON];
		const modal = document.getElementById("componentsDetailsModal");

		function openModal(node) {
			const modalTable = document.getElementById("modalTable");
			modalTable.innerHTML = '';

			if (isCategoryNode(node.id)) {
				const headerRow = document.createElement('tr');
				const header = document.createElement('th');
				header.setAttribute('colspan', '2');
				header.textContent = `${node.label} details (${node.descriptions.size})`;
				headerRow.appendChild(header);
				modalTable.appendChild(headerRow);

				node.descriptions.forEach(desc => {
					const row = document.createElement('tr');
					const cell = document.createElement('td');
					cell.textContent = desc;
					row.appendChild(cell);
					modalTable.appendChild(row);
				});
			}
			else {
				let data = JSON.parse(node.itemData)
				const headerRow = document.createElement('tr');
				const header = document.createElement('th');
				header.setAttribute('colspan', '2');
				header.textContent = capitalizeFirstLetter(data.type) + " details"
				headerRow.appendChild(header);
				modalTable.appendChild(headerRow);
				for (let key in data) {
					if (key !== "children" && key !== "id" && key !== "relationship" && key !== "type" && !(data.type === "file" && data.relationship === "Embedded" && key === "filename")) {
						const row = document.createElement('tr');
						const keyCell = document.createElement('td');
						const valueCell = document.createElement('td');
						keyCell.textContent = adjustProperties(key);
						valueCell.textContent = data[key];
						row.appendChild(keyCell);
						row.appendChild(valueCell);
						modalTable.appendChild(row);
					}
				}
				// NOTE: Do not add XDR link for now
				// if (data.verdict.toLowerCase() === "malicious" && (data.type === "file" || data.type === "url")) {
				// 	const xdr_intelligence_link = build_xdr_intelligence_link(cloud_dns_name.value, data.type === "file" ? data.md5 : data.url, data.relationship.toLowerCase());
				// 	const row = document.createElement('tr');
				// 	const cell = document.createElement('td');
				// 	cell.setAttribute('colspan', '2');
				// 	cell.innerHTML = `<div class="btn-xdr-intel-wrapper">
				//  For more information:&nbsp;
				//  <a class="xdr-intelligence-link" href="${xdr_intelligence_link}" data-balloon="Valid license required" data-balloon-pos="up">Horizon XDR Intelligence</a>
				//  </div>`;
				// 	row.appendChild(cell);
				// 	modalTable.appendChild(row);
				// }
			}
			modal.style.display = "flex";
		}

		const span = document.getElementsByClassName("close")[0];
		span.onclick = function () {
			modal.style.display = "none";
		};

		window.onclick = function (event) {
			if (event.target === modal) {
				modal.style.display = "none";
			}
		};

		const nodes = new vis.DataSet();
		const edges = new vis.DataSet();
		const verdictColors = {
			"malicious": "#ff0000", "suspicious": "#ffa500"
		};

		function addNodesAndEdges(item, parentID) {
			let nodeTitle;
			switch (item.type) {
				case "file":
					nodeTitle = item.filename;
					break;
				case "url":
					nodeTitle = item.url;
					break;
				case "macro":
					nodeTitle = item.sha1;
					break;
			}

			nodes.add({
				id: item.id,
				label: dataNodeToLabel(item),
				title: nodeTitle,
				itemData: JSON.stringify(item),
				image: itemToIcon(item),
			});


			const color = verdictColors[item.verdict.toLowerCase()];
			if (color) {
				nodes.update({
					id: item.id, color: {
						background: color, border: color, highlight: {
							background: color, border: color
						}
					}
				});
			}

			if (parentID !== null) {
				edges.add({
					from: parentID, to: item.id,
					label: item.relationship,
					color: {
						color: "#848484", highlight: "#848484",
					}
				});
			}

			if (item.children && item.children.length > 0) {
				item.children.forEach(function (child) {
					addNodesAndEdges(child, item.id);
				});
			}
		}

		nodesData.forEach(function (item) {
			addNodesAndEdges(item, null);
		});


		const suspNodes = [];
		const suspEdges = [];

		const suspiciousActivities = [
			"Suspicious activity",
			"Suspicious Network activity",
			"Suspicious Process activity",
			"Suspicious File system activity"
		];

		if (Object.keys(suspiciousActivityJson).length > 0) {
			for (let idx = 0; idx < suspiciousActivityJson.images.length; idx++) {
				const image = suspiciousActivityJson.images[idx];
				const imageId = 'image' + idx;
				suspNodes.push({
					id: imageId, label: image.image.replace(/,/g, '\n'), image: "images/graph/image.svg"
				});
				suspEdges.push({from: nodesData[0].id, to: imageId, dashes: true});

				let addedCategories = new Set();

				image.behaviors.forEach((behavior, behaviorIdx) => {
					if (suspiciousActivities.includes(behavior.values[0].type)) {
						const categoryId = 'category' + idx + behavior.category;
						if (!addedCategories.has(categoryId)) {
							suspNodes.push({
								id: categoryId,
								label: behavior.category,
								color: {border: "black"},
								descriptions: new Set(),
								image: "images/graph/category.svg",
								parent: imageId
							});
							suspEdges.push({from: imageId, to: categoryId});
							addedCategories.add(categoryId);
						}

						suspNodes.find(node => node.id === categoryId).descriptions.add(behavior.description);
					}
				});
			}
		}
		const data = {
			nodes: nodes, edges: edges,
		};

		data.nodes.add(suspNodes);
		data.edges.add(suspEdges);

		const options = {
			height: "700",
			nodes: {
				shape: "circularImage",
				borderWidth: 2,
				shadow: true,
				color: {
					border: "white",
					background: "#111b2b",
				},
				font: {
					color: 'white',
					face: 'Open Sans',
					align: 'center',
				},
			},
			edges: {
				length: 200,
				shadow: true,
				color: {
					color: "#A0A0A0",
					highlight: "#A0A0A0",
				},
				smooth: {
					type: "curvedCW",
					roundness: 0.1,
				},
				width: 2,
				font: {
					color: "#ffffff",
					size: 13,
					face: "Arial",
					strokeWidth: 0,
					align: "top",
				},
				hoverWidth: function (width) {
					return 3 * width;
				},
			},
			physics: {
				enabled: true,
				solver: "repulsion",
				repulsion: {
					nodeDistance: 400,
				},
			},
			interaction: {
				hover: true,
			},
		};

		const network = new vis.Network(container, data, options);

		function isCategoryNode(clickedNodeId) {
			return typeof clickedNodeId === 'string' && clickedNodeId.startsWith("category");
		}

		function isImageNode(node) {
			return typeof node.id === 'string' && node.image === "images/graph/image.svg";
		}

		nodes.forEach(node => {
			if (isImageNode(node)) {
				network.cluster({
					joinCondition: function (childOptions) {
						if (node.id === childOptions.id) return true;
						if (!isCategoryNode(childOptions.id)) return false;
						return childOptions.parent && childOptions.parent.includes(node.id);
					}, clusterNodeProperties: {
						id: 'cluster:' + node.label,
						label: node.label,
						shape: 'circularImage',
						image: node.image,
						allowSingleNodeCluster: true
					}
				});
			}
		});

		network.on("selectNode", function (params) {
			const selectedNodeId = params.nodes[0];
			if (params.nodes.length === 1) {
				if (network.isCluster(selectedNodeId)) {
					network.openCluster(selectedNodeId);
				}
				else {
					const clickedNode = nodes.get(selectedNodeId);
					if (clickedNode && (clickedNode.itemData || isCategoryNode(clickedNode.id))) {
						openModal(clickedNode);
					}
				}
			}
		});

		function createBreadcrumb(nodeId) {
			let nodePath = [];
			let currentNode = nodeId;

			while (currentNode !== undefined) {
				let nodeText = network.isCluster(currentNode) ? currentNode.replace(/cluster:keep|cluster:/g, "") : nodes.get(currentNode).label;
				nodePath.unshift(nodeText);
				currentNode = network.getConnectedNodes(currentNode, 'from')[0];
			}

			$('#breadcrumb_text').text(nodePath.join("  →  "));
		}

		network.on("hoverNode", function (params) {
			network.canvas.body.container.style.cursor = 'pointer'
			if (params.node) {
				createBreadcrumb(params.node);
			}
		});
		network.on("blurNode", function (params) {
			network.canvas.body.container.style.cursor = 'default'
		});
		// network.fit({nodes: [nodesData[0].id], animation: true, maxZoomLevel: 0.6});
		network.fit({animation: true});
	}


	this.initComponents = () => {
		try {
			this.components();
		} catch (ex) {
			document.getElementById('components').remove();
			console.log(ex);
		}
	}

	//////////////////
	// Attack Chain //
	//////////////////
	this.atk_chain = () => {
		// Remove the whole section unless there is at least one matched attack chain rule to show
		try {
			var data = (typeof getAttackChainJSON === 'function') ? getAttackChainJSON() : null;

			var ruleIds = (data && data.rule_ids) || [];
			var ruleNames = (data && data.rule_names) || [];
			var severities = (data && data.severities) || [];
			var actives = (data && data.actives) || [];

			var rowsCount = Math.max(ruleIds.length, ruleNames.length, severities.length, actives.length);

			if (!rowsCount) {
				throw 'Not enough data to display the attack chain';
			}
		} catch (ex) {
			$('#atk_chain').remove();
			console.log(ex);
			return;
		}

		var table = ($('<div>\
			<table class="table">\
				<thead>\
					<tr>\
						<td>Rule ID</td>\
						<td>Rule Name</td>\
						<td>Severity</td>\
						<td>Active</td>\
					</tr>\
				</thead>\
				<tbody></tbody>\
			</table>\
		</div>').appendTo($('#atk_chain_inner'))).find('table');

		for (var i = 0; i < rowsCount; i++) {
			var $row = $('<tr></tr>');
			$row.append($('<td></td>').text(ruleIds[i] !== undefined ? ruleIds[i] : ''));
			$row.append($('<td></td>').text(ruleNames[i] !== undefined ? ruleNames[i] : ''));
			$row.append($('<td></td>').text(severities[i] !== undefined ? severities[i] : ''));
			$row.append($('<td></td>').text(actives[i] !== undefined ? actives[i] : ''));
			$row.appendTo(table);
		}

		var rows_count = $(table).find('tbody tr').length;
		if (rows_count > 15)
			addTableFeatures(table, rows_count > 500 ? true : false);
	}

	// this.reloadComponents = () => {
	// 	// Don't reload if the section doesn't exist
	// 	if (!document.getElementById('components')) {
	// 		return;
	// 	}
	//
	// 	// Get rid of the current graph before recreating it
	// 	const old_svg = document.getElementById("components_svg");
	// 	if (old_svg) {
	// 		old_svg.remove();
	// 	}
	//
	// 	this.components(getAttackComponentsJSON());
	// }

	////////////////////////
	// Emulation Timeline //
	////////////////////////
	this.events = () => {
		/**
		 * Loads an external script, fetches some data using a function within that script and builds a table of the events.
		 *
		 * @param {string} fileName Relative path to the script to load.
		 * @param {string} funcName Function to call from within the script.
		 * @param {object} div      Element to build the table in.
		 * @param {object} image    An object with some image-specific properties.
		 */
		this.loadEvents = (fileName, funcName, div, image) => {
			addScript(() => {
				var data = window[funcName]();
				(new EventsData(image)).buildTable(div, data);

				/* this.loadEvents() is called for each image showed in report and its data
 				   is saved in this.eventsPerImage */
				this.eventsPerImage[image.uid] = data;
				/* Once this.loadEvents() has been called for all images,
				   all the data is sent for a function related to the Malware Family section */
				if(Object.keys(this.eventsPerImage).length == this.images.length) {
					this.malware_family_obj.createSimilarCommunication(this.eventsPerImage);
				}
			}, fileName);
		}

		/**
		 * Getting the pcaps data and preparing a dictionary that maps the prefix of an image uid to the uri
		 * of its corresponding pcap file (if exists).
		 * When a specific image pill (tab) is selected in the emulation timeline section, an icon for downloading
		 * its corresponding pcap file will be shown, if exists.
		 */
		var pcapsData = getPcaps();
		EventsData.pcaps = {};
		for(var i = 0; i < pcapsData.length; ++i) {
			var pcap = pcapsData[i];
			var pcapKey = pcap['image_uid'].split('-')[0]; // The key is the prefix of the uid
			EventsData.pcaps[pcapKey] = pcap['url'];
		}

		// Getting the Detailed Behavioral reports (Cuckoo reports) data and preparing them for download
		var detailedBehavioralReportsData = getDetailedBehavioralReports()
		EventsData.detailedBehavioralReports = {};
		for(var i = 0; i < detailedBehavioralReportsData.length; ++i) {
			var report = detailedBehavioralReportsData[i];
			var report_key = report['image_uid'].split('-')[0]; // The key is the prefix of the uid
			EventsData.detailedBehavioralReports[report_key] = report['url'];
		}

		// Getting the SBA report  data and preparing them for download
		var SBAReportData = getSBAReport()
		EventsData.SBAReport = {};
		if (SBAReportData.length > 0) {
			EventsData.SBAReport["path"] = SBAReportData[0]["path"];
		}

		// Listener for toggling between Timeline and Table views
		$('#timelines #timeline-toggle a[data-toggle="tab"]').on('shown.bs.tab', function() {
			$([this, $(this).siblings()]).toggleClass('active');
			updateTimeline();
		});

		// Create the Timeline
		buildTimeline();

		// Static counter so that EventsData class could know when it's working on the last image
		EventsData.imageCount = this.images.length;

		// Iterate over the images and load their events (into the Timeline and into the Table)
		for (var image in this.images) {
			var currImage = this.images[image];
			var imageUid = currImage.uid.split('-')[0];

			var fileName = 'json/events_' + imageUid + '.js';
			var funcName = "getEmulationEventsJSON_" + imageUid;

			var image = {
				uid: imageUid,
				name: currImage.name,
				verdict: verdicts[currImage.verdict.toUpperCase()].img
			};

			this.loadEvents(fileName, funcName, $('#events_table'), image);
		}
	};

	this.mitre = () => {
		var data = getMitreJson();
		try {
			(new MitreData(data)).buildTable();
		} catch (ex) {
			$('#mitre').remove();
			console.debug(ex);
		}
	}

	this.hideElements = () => {
		// mitre_data globally defined object
		if (jQuery.isEmptyObject(mitre_data)) {
            $('#mitre').remove();
        }
	}

	///////////////////////////
	// Suspicious Activities //
	///////////////////////////
	this.susp_actv = () => {
		// Get the "Suspicious Activities" data
		var data = getSuspActvJSON();

		/**
		 * This JSON splits the data into images, even though currently we don't really care about each image individually. (maybe will use in the future)
		 * Because of that, there's a nested for-loop which is responsible for adding the rows to the table.
		 * We're also using a 'count' to link between rows and their popups. (not to be mistaken with the 'count' of each 'behavior')
		 */
		var count = 0;
		for (var image in data.images) {
			var currImage = data.images[image];
			var behaviors = currImage.behaviors;

			if (behaviors) {
				var div = $('#susp_act .panel-body');
				var tableId = 'suspActvTable' + image;
				var imageName = currImage.image.replace(/,/g, ', ');

				// Create a tab for the current image
				$('<li' + (count == 0 ? ' class="active"' : '') + '>\
					<a data-toggle="tab" href="#' + tableId + '">' + imageName + '</a>\
				</li>').appendTo(div.find('.nav-tabs'));

				// Create a suspicious activities table for the current image
				var table = ($('<div id="' + tableId + '" class="tab-pane fade' + (count == 0 ? ' in active' : '') + '">\
					<h4 style="font-weight: bold;" class="only-in-print">' + imageName + '</h4>\
					<table class="table">\
						<thead>\
							<td>Category</td>\
							<td>Count</td>\
							<td>Description</td>\
						</thead>\
						<tbody></tbody>\
					</table>\
				</div>').appendTo(div.find('.tab-content'))).find('table');

				for (var behavior in behaviors) {
					var currBehavior = behaviors[behavior];
					var popupId = "susp_actv_popup_" + count;

					// Add the row to the table
					var $row = $('<tr popup="' + popupId + '"></tr>');
					$row.append($('<td></td>').text(currBehavior.category));
					$row.append($('<td></td>').text(currBehavior.count));
					$row.append($('<td></td>').text(currBehavior.description));
					$row.appendTo(table);

					// Create the popup
					var popupBuilder = new Popup('#popups');
					popupBuilder.id = popupId;
					popupBuilder.title = 'Suspicious Activity';

					var $popupContent = $('<div></div>');
					$popupContent.append($('<h3></h3>').text(currBehavior.category));
					$popupContent.append($('<h5 style="white-space: pre-line;"></h5>').text(currBehavior.description));
					var $tableDiv = $('<div style="overflow: auto;"></div>');
					var $popupTable = $('<table class="table"><thead><tr><td>Type</td><td>Value</td></tr></thead><tbody></tbody></table>');
					currBehavior.values.forEach(function(val) {
						var $valRow = $('<tr></tr>');
						$valRow.append($('<td></td>').text(val.type));
						$valRow.append($('<td></td>').text(val.value));
						$valRow.appendTo($popupTable.find('tbody'));
					});
					$tableDiv.append($popupTable);
					$popupContent.append($tableDiv);
					popupBuilder.content = $popupContent.html();
					var popup = popupBuilder.addPopup();

					// Add to the table searching and sorting features if it's big enough
					var popupTable = popup.find('table');
					var rows_count = popupTable.find('tbody tr').length;
					if (rows_count > 15)
						addTableFeatures(popupTable, rows_count > 500 ? true : false);

					count++;
				}

				// Apply DataTables to the newly created table (if the size requires it)
				var rows_count = $(table).find('tbody tr').length;

				if (rows_count > 15)
					addTableFeatures(table, rows_count > 500 ? true : false);
			}
		}

		// We could add an if-else to check whether there's data but we already have the 'count' so better use it
		if (!count)
			$('#susp_act').remove();
	};

	// Suspicious Activities - Export CSV
	$('#susp_act_export_csv a').on('click', function(event) {
		event.preventDefault();

		var activePill = $(this).parents('.panel').find('.nav-pills .active a');
		var table = $('#timelines #events_table ' + activePill.attr('href') + ' table');
		var headers = ['Image', 'Category', 'Count', 'Description', 'Type', 'Value'];

		var csvContent = headers.join() + '\n';

		// Images (Image column)
		$('#susp_act .tab-content .tab-pane').each(function() {
			csvContent += getCSVString($(this).find('h4').text());
			csvContent += ','.repeat(headers.length - 1) + '\n';  // Blanks

			// Behaviors (Category, Count, Description columns)
			$(this).find('table tbody tr').each(function() {
				csvContent += ',';  // Blank
				csvContent += $(this).find('td').map(function() {
					return getCSVString(this.innerText);
				}).get().join();
				csvContent += ','.repeat(headers.length - 4) + '\n';  // Blanks

				// Values (Type, Value columns)
				$('#' + $(this).attr('popup') + ' table tbody tr').each(function() {
					csvContent += ','.repeat(headers.length - 2);  // Blanks
					csvContent += $(this).find('td').map(function() {
						return getCSVString(this.innerText);
					}).get().join() + '\n';
				});
			});
		});

		createCSV(csvContent, 'suspicious_activities.csv');
	});

	////////////////
	// Emulation Videos //
	////////////////
	this.emu_videos = () => {

		var imagesVideoData = getEmulationVideosJSON();

		// Inform the EmulationVideo class of the amount of images
		EmulationVideo.imageCount = imagesVideoData.length;

		if(EmulationVideo.imageCount > 0) {
			// Iterate over the images and create their video objects
			for (var i = 0; i < imagesVideoData.length; ++i) {
				EmulationVideo('#emu-videos', imagesVideoData[i]);
			}
		}
		else {
			// If there are no videos at all, from any image, then remove the section
			$('#emu-videos').parents('.panel').remove();
		}
	};

	////////////////////
	// Snapshot Image //
	////////////////////
	this.snapshot_image = () => {
		var snapshotImageData = getSnapshotJSON();

		//There will be only one snapshot so iteration is not needed.
		if(snapshotImageData.length > 0) {
			SnapshotImage('#snap-image', snapshotImageData[0]);
		}
		else {
			// If there is no snapshot image at all then remove the section
			$('#snap-image').parents('.panel').remove();
		}
	};

	/////////////////
	// Malware Family //
	/////////////////
    	this.malware_family = () => {
		this.malware_family_obj = new MalwareFamily();
		this.malware_family_service = new MalwareFamilyService(this.malware_family_obj);
	};

	this.false_positive = () => {
		if(this.fileMD5 && this.fileMD5.length == 32 /* MD5 length*/) {
			this.false_positive_service = new FalsePositiveService(this.fileMD5);
		}
	}

	// Conveniently load all the setions without loading each one separately.
	this.loadAll = () => {
		this.tech_details();
		this.general_results();
		this.attack_vec();
		this.initComponents();
		this.atk_chain();
		//placing it before emulation videos for better viewing 
		this.snapshot_image(); 
		this.emu_videos();
		this.susp_actv();
		this.malware_family();
		/* The Events (Advanced Forensics) section should be initiallized AFTER the Malware Family
		section, since in the end of the Events section initiallization a function of
		the Malware Family section is called and the Malware Family section should have be initiallized
		already by then */
		this.events();
		this.mitre();
		this.false_positive();

		this.hideElements();
	};

	// this.reloadOnResize = () => {
	// 	this.reloadComponents()
	// }
}
